import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WhatIsHsaPage } from './what-is-hsa';

@NgModule({
  declarations: [
    WhatIsHsaPage,
  ],
  imports: [
    IonicPageModule.forChild(WhatIsHsaPage),
  ],
})
export class WhatIsHsaPageModule {}
